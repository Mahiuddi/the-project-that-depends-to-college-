
<?php

include "include/connection.php";



if(!empty($_POST['search'])){

  $search=$_POST['search'];
  $sql="SELECT * FROM employess  where CONCAT(emp_name , emp_fname , emp_username , emp_job) LIKE '%$search%'";
  mysqli_set_charset($connection,"utf8");
  $result=mysqli_query($connection,$sql);

  


}else{

  $sql="SELECT * FROM employess";
  mysqli_set_charset($connection,"utf8");
  $result=mysqli_query($connection,$sql);

  
  
  
}




?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap  CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="boot/css/mycss.css">
  <title>Hello, world!</title>
</head>

<body>

  <div class="container-fluid">
    <div class="row"  id="top"> 
      <div class="col-md-3">
      logo place <!-- here we can add any logo we want -->
      </div>
      <div class="col-md-6">
        
      </div>
      <div class="col-md-3">
        <h2 id="debt_name">خدمات نرم افزاری</h2>
      </div>
    </div>
    <br>

    <div class="row">
        <div class="col-md-4" id="menu">
          <ul class="nav nav-pills">
            <li class="nav-item">
              <a class="nav-link active" href="add_item.php">جنس جدید</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="add_emp.php">کامند جدید</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.php">لیست اجناس</a>
            </li>
            
          </ul>
        </div>

        <div class="col-md-6" id="fsearch">
            <form class="form-inline" action="" method="post">
                <div class="form-group">
                  <input type="text" class="form-control" name="search" placeholder="جستجو">

                  <button type="submit" class="btn btn-success"> جستجو</button>
                </div>
                
                
              </form>
        </div>

        <div class="col-md-2">
          <h2 class="title">لیست کارمندان</h2>
        </div>

      </div>
      <br>

      <div class="row" id="content">
        <div class="col-md-12">
                  <table class="table table-striped" dir="rtl">
                    <thead>
                        <tr class="success">
                          <th>نام کارمند</th>
                          <th>نام پدر</th>
                          <th>تخلص</th>
                          <th>وظیفه</th>
                          <th>عملیات</th>

                        </tr>
                    </thead>
                    <TBODy>

                    <?php





                  
                   if(mysqli_num_rows($result)>0){
                      while($row=mysqli_fetch_row($result)){

                        echo "<tr>";
                            echo"<td>".$row[1]." </td>";
                            echo"<td>".$row[2]." </td>";
                            echo"<td>".$row[3]." </td>";
                            echo"<td>".$row[4]." </td>";
                            echo"<td><a href='edit_emp.php?id=".$row[0]."'>اصلاح</a> </td>";

                        echo "<tr>";

                      }

                   }
                    
                    ?>


                     

                      
                    </TBODy>


                  </table>
        </div>
      </div>

  </div>








  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
    integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
    crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
    integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
    crossorigin="anonymous"></script>
</body>

</html>