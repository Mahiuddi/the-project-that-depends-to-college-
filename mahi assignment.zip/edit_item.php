
<?php

include "include/connection.php";

$name="";
$idate="";
$price="";
$emp="";
$id=$_GET['id'];

if(isset($_POST['subbnt'])){

  if(!empty($_POST['name'])){
    $name=$_POST['name'];}

 if(!empty($_POST['idate'])){
   $idate=$_POST['idate'];
 }
 if(!empty($_POST['price'])){
  $price=$_POST['price'];
}

if(!empty($_POST['emp'])){
  $emp=$_POST['emp'];
}
$upsql="update items set item_name='$name',item_date='$idate',item_price=$price,item_emp=$emp where item_id=$id";
  
  if(mysqli_query($connection,$upsql)){


    echo "موفقانه ویرایش شد ";
    header("location:index.php");
  }else{
    echo "موفقانه ویرایش نشد ";
    header("location:edit_item.php?id=$id");
  }

}else{


$sql="SELECT emp_id , emp_name from employess";
$r=mysqli_query($connection,$sql);

$isql="SELECT * from items where item_id=$id";
$ir=mysqli_query($connection,$isql);
$irow=mysqli_fetch_row($ir);


}

?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap  CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="boot/css/mycss.css">
  <title>Hello, world!</title>
</head>

<body>

  <div class="container-fluid">
    <div class="row"  id="top"> 
      <div class="col-md-3">
      logo place <!-- here we can add any logo we want -->
      </div>
      <div class="col-md-6">
        
      </div>
      <div class="col-md-3">
        <h2 id="debt_name">خدمات نرم افزاری</h2>
      </div>
    </div>
    <br>

   
   
    <div class="row">
        <div class="col-md-4" id="menu">
          <ul class="nav nav-pills">
            <li class="nav-item">
              <a class="nav-link active" href="index.php"> برگشت</a>
            </li>
          
          </ul>
        </div>

      

<br><br>

<div class="container">
      <div class="row" dir="rtl" >
        <div class="col-md-12" >
          <h2 class="title" style="text-align: right;">ویرایش کردن جنس </h2>

<br><br>

         
          <form  style="text-align: right;" action=""  method="POST">
              <div class="form-group row">
                <label for="inputEmail3" class="col-sm-2 col-form-label">نام جنس</label>
                <div class="col-sm-10">
                  <input type="text" name="name" value="<?php if(!empty($irow[1])){ echo $irow[1]; } ?>"
                   class="form-control" id="inputEmail3" placeholder="نام جنس">
                </div>
              </div>


              <div class="form-group row">
                  <label for="inputEmail3" class="col-sm-2 col-form-label"> قیمت</label>
                  <div class="col-sm-10">
                    <input type="text" name="price" value="<?php if(!empty($irow[2])){ echo $irow[2]; } ?>"
                     class="form-control" id="inputEmail3" placeholder="قیمت ">
                  </div>
                </div>
             

                <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label"> تاریخ</label>
                    <div class="col-sm-10">
                      <input type="text" name="idate" value="<?php if(!empty($irow[3])){ echo $irow[3]; } ?>"
                       class="form-control" id="inputEmail3" placeholder="تاریخ ">
                    </div>
                  </div>

                  <div class="form-group row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label"> کارمند</label>
                      <div class="col-sm-10">
                        <select name="emp" id="employee" class="form-control">


                          <?php
                          if(isset($r)){
                            while($row=mysqli_fetch_row($r)){
                              echo "<option value'".$row[0]."'>".$row[1]."</option>";
                            }
                          }
                          
                          ?>


                        </select>
                      </div>
                    </div>
                  

              <div class="form-group row">
                  <div class="col-sm-10"></div>
                <div class="col-sm-2">
                  <button type="submit" name="subbnt" class="btn btn-primary btn-block"> ویرایش  </button>
                </div>
                
              </div>
            </form>
      



        

      </div>
    </div>  
      









  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
    integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
    crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
    integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
    crossorigin="anonymous"></script>

</body>

</html>