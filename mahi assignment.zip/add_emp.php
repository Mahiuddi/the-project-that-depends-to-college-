
<?php

include "include/connection.php";




?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap  CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="boot/css/mycss.css">
  <title>Hello, world!</title>
</head>

<body>

  <div class="container-fluid">
    <div class="row"  id="top"> 
      <div class="col-md-3">
      logo place <!-- here we can add any logo we want -->
      </div>
      <div class="col-md-6">
        
      </div>
      <div class="col-md-3">
        <h2 id="debt_name">خدمات نرم افزاری</h2>
      </div>
    </div>
    <br>
    <?php
    
    $name='';
$fname="";
$surname="";
$job="";

if(isset($_POST['subbtn'])){
  if(!empty($_POST['name'])){
    $name=$_POST['name'];
  }
  if(!empty($_POST['fname'])){
    $fname=$_POST['fname'];
  }
  if(!empty($_POST['surname'])){
    $surname=$_POST['surname'];
  }
  if(!empty($_POST['job'])){
    $job=$_POST['job'];
  }
  
  $sql="INSERT INTO employess value(null,'$name','$fname','$surname','$job')";
  
  if(mysqli_query($connection,$sql)){
    echo " ریکورد موفقانه اضافه شد  ";
  }
  else{
    echo " ریکورد موفقانه اضافه نشد";
  }
  


}

    ?>
    <div class="row">
        <div class="col-md-4" id="menu">
          <ul class="nav nav-pills">
            <li class="nav-item">
              <a class="nav-link active" href="list_emp.php"> برگشت</a>
            </li>
          
          </ul>
        </div>

        

      </div>
      <br>

      <div class="row"  dir="rtl" id="content">
      <div class="col-md-12" >
          <h2 class="title" style="text-align: right;">اضافه کردن کامند جدید</h2>

<br><br>

         
          <form  style="text-align: right;" action="" method="POST">
              <div class="form-group row" >
                <label for="inputEmail3"  class="col-sm-2 col-form-label">نام کامند</label>
                <div class="col-sm-10">
                  <input type="text" name="name" class="form-control" id="inputEmail3" placeholder="نام کامند">
                </div>
              </div>

              <div class="form-group row">
                  <label for="inputEmail3" class="col-sm-2 col-form-label"> نام پدر</label>
                  <div class="col-sm-10">
                    <input type="text" name="fname" class="form-control" id="inputEmail3" placeholder="نام پدر">
                  </div>
                </div>

                <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label"> تخلص</label>
                    <div class="col-sm-10">
                      <input type="text" name="surname" class="form-control" id="inputEmail3" placeholder="تخلص ">
                    </div>
                  </div>

                  <div class="form-group row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label">وظیفه </label>
                      <div class="col-sm-10">
                        <input type="text" name="job" class="form-control" id="inputEmail3" placeholder="وظیفه ">
                      </div>
                    </div>
             

              <div class="form-group row">
                  <div class="col-sm-10"></div>
                <div class="col-sm-2">
                  <button type="submit" name="subbtn" class="btn btn-primary btn-block">اضافه کردن </button>
                </div>
                
              </div>
            </form>
      



        

      </div>
      </div>

  </div>








  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
    integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
    crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
    integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
    crossorigin="anonymous"></script>
</body>

</html>