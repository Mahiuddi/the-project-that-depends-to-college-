<?php

$mysql_host='localhost';
$mysql_user='root';
$mysql_password='12345678';
$database='inventory';

//@mysqli_connect($mysql_host,$mysql_user,$mysql_password) or die(" you can't connect to server"); // exit(" you can't connect to server");


$connection=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$database);
if(!$connection){

    die(" you can't connect to server");


}

?>